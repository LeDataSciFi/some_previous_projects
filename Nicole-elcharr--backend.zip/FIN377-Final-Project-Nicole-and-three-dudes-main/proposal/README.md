# Research Proposal: 

Nathan Alakija, Nicole ElChaar, Mason Otley, Xiaozhe Zhang

*Lehigh University College of Business*

---

## Research Question

There is an idea of shared value by Michael Porter that correlates productive environmental governance ingrained into the business model with increased business success. In the social and economic climate of today, we believe that companies displaying care and concern have the most success for their stakeholders.

Because of the emergence of ESG scores in the past decade, we want to analyze the financial performance of selected companies by introducing ESG consideration as a critical factor. Though ESG scores have recently come under criticism[[1]](#1), our initial hypothesis is that companies with a high focus on ESG will have a relatively high company performance over time. We want to create a relationship model to understand the correlation between these factors. In addition, we will create a predictive model using ESG metrics and financial performance to predict prices over time.  We will display the performance of our portfolio against the S&P 500, highlighting the combinations of ESG metrics and financial values that give the best performance.  As the objective of the predictive model is to predict companies' stock prices based on ESG performance, our success metrics could be the Mean Absolute Error (MAE) or Root Mean Squared Error (RMSE) of the model's predictions compared to the actual stock prices.

### The Big Picture

Has ESG changed the landscape of business? Is it a viable measurement correlated with increased company performance?

1. Have increasing ESG scores correlated with high or increasing stock returns?
1. Can ESG provide any value in predicting performance in the future?

### Hypotheses

- We expect that positive ESG related metrics will coincide with increasing stock returns.
- We believe we will find that ESG related metrics provide some value in forecasting performance.

The expected conclusions drawn from the analysis of increased ESG related metrics contrasted with the highest ESG metrics will differ. So, increased ESG metric analysis will display trends and growth correlation between stock returns whereas the highest returns will show the correlation between ESG metrics and stock returns.	

---

## Data

In our final dataset, we will show company returns, ESG metrics, and financial performance over monthly intervals.  All values will lag the returns (monthly, quarterly, and yearly) so we can appropriately estimate performance into the future. Each instance in this dataset is a company in the S&P 500 from January 2013 to January 2020.

The columns are the following:

| Company Name | Ticker | CIK (unique) | ESG Metrics | ESG Score Synthesis (our ESG score) | Industry Sector | Market Capitalization | Financial Performance Metrics | Date (Month/Year) | Return (%) |
|----------|----------|----------|----------|----------|----------|----------|----------|----------|----------|

---

### Data Pipeline

#### Acquisition

Initially, we will collect monthly stock returns, market caps, and other financial information using the Yahoo Finance Python package. ESG Metrics will be downloaded using the Bloomberg Terminals and other related sources. Optionally, we will scrape news articles to gain information about each company, associating the company with a select list of topics for the user to filter between.

#### Manipulation

##### Relationship Model

For our relationship model, we will plot each company’s ESG score on the X axis and return over a selected period of time on the Y axis. We will use the ESG data from different sources including Bloomberg, MSCI, Yahoo Finance, and more to find ESG metrics that represent the environmental, social, and governance quality of the companies included in the study. On the dashboard, the user will be able to select an ESG metric and a range of that ESG metric. The return of each company will be compared against others, with the return of market indices also optionally shown. 
Firstly, we will construct a linear regression on the past stock price while using multiple ESG scores from (5) different rating agencies. This is a simple linear regression model to find out which ESG rating agency’s ESG scores would associate the most with the stock return. Then, we will use the coefficients of different ESG scores of different agencies to weight and comprehensive ESG Score (AKA, our own ESG score, **“ESG Score Synthesis”**)
Next, we will create a plot with **ESG Score Synthesis** as x axis and stock return/price as y-axis. Therefore, we will use this plot to examine our hypothesis 1 whether higher ESG score associates with high stock performance
The relationship model plots allows users to select which ESG rating agency’s ESG score to use and show how this particular ESG score relates with the stock return. However, the plot of **ESG Score Synthesis** with stock return is the default for visualization. 
We will start by computing monthly percent returns for each company from January 2013 through January 2020.  The user can select in the plot the time horizon to examine (e.g. returns from Jan 2013 - Dec 2014) in the graph.

##### Predictive Model

In our predictive model, we will find the relationship between ESG metrics and returns. We will compute the best aggregation of ESG scores and financial metrics relative to performance for Q1 of 2013 to Q4 of 2017, attempting to optimize the model. Once our ESG scores are generated, we will forecast returns into 2018 and 2019 based on ESG metrics. As in the relationship model, ESG metrics for the predicted time horizon will be shown on the X axis and actual and predicted relative returns will be shown on the Y axis. The best model to use is to be determined. Therefore, we will use our model to examine our hypothesis 2 whether ESG provides any value in predicting performance in the future.


## References

<a id="1">[1]</a>
[Another Black Eye for ESG in MSCI’s Mass Ratings Downgrade - Bloomberg](https://www.bloomberg.com/opinion/articles/2023-04-03/another-black-eye-for-esg-in-msci-s-mass-ratings-downgrade)

---

## Sample Dashboard
![Sample Dashboard](Website-UI/UI-2023-04-02.png)

1. The relationship model would show how the ESG index is related to the company performance over ESG score and the Y axis as Return (related to stock return/price).
As mentioned in the Manipulation section of the Relationship Model, we will create a plot with **ESG Score Synthesis** as x axis and stock return/price as y-axis. 
1. The predictive model will show the relationship between our best ESG score estimate with returns over or under the market.
Maybe we use ESG as a critical predictor that what we think the company’s stock price supposed to be: overvalued/undervalued (as shown on our score section on the dashboard)
1. The search bar is used to select the company and/or theme (basket of companies). Each company will show up as a red point on the graph.
1. There will be tab allowing users to view company's performances overtime (ex, monthly, yearly) and select the date range (ex, 2018-2019)
1. We will also include a separate tab/page to describe the data processing and methodology, along with current research in the area of ESG scoring and forecasting.
1. Summary/discussion of the frontier of research in the ESG field, URL imbedded



